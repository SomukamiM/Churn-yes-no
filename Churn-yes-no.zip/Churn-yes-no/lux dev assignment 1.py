#!/usr/bin/env python
# coding: utf-8

# # Machine Learning Model on Predicting if a Customer is Going to Leave

# # Preliminary Wrangling

# # load dataset

# In[117]:


# importing the necessary modules
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sb


# In[118]:


# reading the tsv file that has been downloaded
df= pd.read_csv('WA_Fn-UseC_-Telco-Customer-Churn.csv')
df


# In[119]:


# Check to see the properties of the dataset
df.info()


# In[120]:


# checking the number of rows and column
df.shape


# In[121]:


# Look for missing values
df.isnull().sum()


# In[122]:


# checking the datatypes of each column
df.dtypes


# In[123]:


# decribing a numeric column
df["MonthlyCharges"].describe()


# # Converting data to correct datatype

# In[124]:


# converting the columns that are supposed to be categories that we're going to use
df["Churn"] = df["Churn"].astype('category')
df["gender"] = df["gender"].astype('category')
df["Partner"] = df["Partner"].astype('category')
df["Dependents"] = df["Dependents"].astype('category')


# In[125]:


# confirming to see if they were converted
df["Churn"].dtypes


# # What is the structure of your dataset?
# # What is/are the main feature(s) of interest in your dataset?
# # What features in the dataset do you think will help support your investigation into your feature(s) of interest?

# In[126]:


# creating a dataframe of the categorcal columns
df1=df[['customerID','gender','Partner','Dependents','MonthlyCharges','Churn']]
df1.head()


# In[127]:


# Perfom some feature engineering converting yes/no in the churn column to 1/0
df1["Churn"] = df1["Churn"].cat.codes


# In[128]:


df1


# # Univariate Exploration
# We'll investigate distributions of th individual variable churn.

# # The frequency of the monthly charges

# In[90]:


# plot graph
def histogram_solution_3():
  # data setup
    binsize = 50
    bins = np.arange(0, df['MonthlyCharges'].max()+binsize, binsize)
    plt.hist(data = df, x = 'MonthlyCharges', bins = bins)

plt.xlabel('MonthlyCharges ($)')
plt.ylabel('count')
plt.title(' distribution')
histogram_solution_3()


# In[ ]:


# plot graph
def histogram_solution_3():
  # data setup
    binsize = 50
    bins = np.arange(0, df[''].max()+binsize, binsize)
    plt.hist(data = df, x = '', bins = bins)

plt.xlabel(' ($)')
plt.ylabel('count')
plt.title(' distribution')
histogram_solution_3()


#  The bulk of thr customes pay between $ 50 and 100

# # plot the frequency of churn

# Churn rate= number of customers lost during period/number of customers at start of period*100
#           =1869/7043*100
#           =26.54%

# In[79]:


freq_churn=df1['Churn'].value_counts()
freq_churn


# In[81]:


df1.Churn.value_counts().plot(kind='bar')


# The Nos have the highest frequency of 5000 meaning that the number of customers who stay is more than the one's who leave.

# # Bivariate Exploration
# In this section, we'll investigate relationships between pairs of variables in the data.

# # How many people of each gender stay and how many leave?

# In[85]:


# generate a frequency count of each category for each variable
counts = df1.groupby(['Churn', 'gender']).size().reset_index(name='count')

# create a bar plot
fig, ax = plt.subplots()
ax = counts.pivot(index='Churn', columns='gender', values='count').plot(kind='bar', ax=ax)
plt.show()


# The number of females who leave is more than the number of men who leave by a small margin,while the number of  women who stay is less than the number of men who stay by a small margin.

# # How many people with partnersleave and how many stay?

# In[87]:


# generate a frequency count of each category for each variable
counts = df1.groupby(['Churn', 'Partner']).size().reset_index(name='count')

# create a stacked plot
fig, ax = plt.subplots()
ax = counts.pivot(index='Churn', columns='Partner', values='count').plot(kind='bar', ax=ax)
plt.show()


# The people without partners leave more  than the ones with  the people with partners are more likely to stay compared than the ones with them

# # How many people with dependents are likely to stay?

# In[88]:


# generate a frequency count of each category for each variable
counts = df1.groupby(['Churn', 'Dependents']).size().reset_index(name='count')

# create a  bar plot
fig, ax = plt.subplots()
ax = counts.pivot(index='Churn', columns='Dependents', values='count').plot(kind='bar', ax=ax)
plt.show()


# The number of people that left, the ones with dependants are less than the ones without. While the one's without dependants stayed in large numbers compared to thoe without

# ## Churn prediction is a binary classification problem.Falling under logistic regression.
#   First we'll prepare data then fit the model and finally get summary

# ### Label Encoder converts categorical columns to numerical by simply assigning integers to distinct values

# In[129]:


# encoding the categorical data
df1["gender"] = df1["gender"].cat.codes
df1["Partner"] = df1["Partner"].cat.codes
df1["Dependents"] = df1["Dependents"].cat.codes
df1.head()


# In[130]:


# import packages for the machine learning model
import sklearn
import xgboost as xgb


# In[131]:


#create feature set and labels
X = df1.drop(['Churn','customerID'],axis=1)
y = df1.Churn
#train and test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.05, random_state=56)
#building the model & printing the score
xgb_model = xgb.XGBClassifier(max_depth=5, learning_rate=0.08, objective= 'binary:logistic',n_jobs=-1).fit(X_train, y_train)
print('Accuracy of XGB classifier on training set: {:.2f}'
       .format(xgb_model.score(X_train, y_train)))
print('Accuracy of XGB classifier on test set: {:.2f}'
       .format(xgb_model.score(X_test[X_train.columns], y_test)))


# By using this method we achieved 75% accuracy. Churn rate is 26.5% meaning model perfomance would be 73.5% making model useful.

# In[133]:


# check the classification model to see where exactly our model fails.
from sklearn.metrics import classification_report
y_pred = xgb_model.predict(X_test)
print(classification_report(y_test, y_pred))


# The problem is our precision and recall meaning we should improveby including more data in the model.

# In[134]:


# check which features were used by the model
from xgboost import plot_importance
fig, ax = plt.subplots(figsize=(10,8))
plot_importance(xgb_model, ax=ax)


# importance was given to monthly charges

# In[ ]:




